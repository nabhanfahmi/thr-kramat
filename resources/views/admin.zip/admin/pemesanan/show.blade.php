@extends('admin.layout.admin')

@section('content')
<h1>Detail Pemesanan #{{ $pemesanan->id }}</h1>

<table class="table">
    <tr><th>User</th><td>{{ $pemesanan->user->name ?? '-' }}</td></tr>
    <tr><th>Tiket</th><td>{{ $pemesanan->tiket->nama_tiket ?? '-' }}</td></tr>
    <tr><th>Jumlah</th><td>{{ $pemesanan->jumlah_tiket }}</td></tr>
    <tr><th>Total Harga</th><td>Rp {{ number_format($pemesanan->total_harga, 0, ',', '.') }}</td></tr>
    <tr><th>Status</th><td>{{ ucfirst($pemesanan->status) }}</td></tr>
    <tr><th>Tanggal Pemesanan</th><td>{{ $pemesanan->created_at->format('d-m-Y H:i') }}</td></tr>
</table>

<h3>Status Pemesanan</h3>

@if($pemesanan->status == 'menunggu')
    <div class="alert alert-warning">Menunggu pembayaran dari user.</div>
@elseif($pemesanan->status == 'dibayar')
    <form action="{{ route('admin.pemesanan.updateStatus', $pemesanan->id) }}" method="POST">
        @csrf
        <input type="hidden" name="status" value="selesai">
        <button class="btn btn-success mt-2" type="submit"
            onclick="return confirm('Yakin ingin menyelesaikan pemesanan ini?')">
            Konfirmasi Selesai
        </button>
    </form>
@elseif($pemesanan->status == 'selesai')
    <div class="alert alert-success">Pemesanan telah selesai.</div>
@elseif($pemesanan->status == 'batal')
    <div class="alert alert-danger">Pemesanan dibatalkan.</div>
@endif

<a href="{{ route('admin.pemesanan.index') }}" class="btn btn-secondary mt-3">Kembali ke Daftar Pemesanan</a>
@endsection
